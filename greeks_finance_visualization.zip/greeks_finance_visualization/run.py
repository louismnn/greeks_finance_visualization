import Python.app.app.main

if __name__ == "__main__":
    app = Python.app.app.main.app
    app.run(debug=True)